# conftest.py for global pytest fixtures (if needed)
