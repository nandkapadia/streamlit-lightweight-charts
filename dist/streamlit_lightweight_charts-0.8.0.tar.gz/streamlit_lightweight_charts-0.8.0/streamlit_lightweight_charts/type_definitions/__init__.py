"""Types module for streamlit-lightweight-charts."""

from .enums import (
    ChartType,
    ColorType,
    LineStyle,
    LineType,
    CrosshairMode,
    PriceScaleMode,
    LastPriceAnimationMode,
    HorzAlign,
    VertAlign,
)
from .colors import Background, SolidColor, VerticalGradientColor
from .protocols import (
    ChartDataProtocol,
    TimeSeriesDataProtocol,
    SeriesOptionsProtocol,
    ChartOptionsProtocol,
    SeriesProtocol,
    ChartProtocol,
    MarkerProtocol,
    TradeProtocol,
    AnnotationProtocol,
    TooltipProtocol,
    VisualizationOptionsProtocol,
    ChartData,
    SeriesOptions,
    ChartOptions,
    TimeValue,
    NumericValue,
)

__all__ = [
    # Enums
    "ChartType",
    "ColorType",
    "LineStyle",
    "LineType",
    "CrosshairMode",
    "PriceScaleMode",
    "LastPriceAnimationMode",
    "HorzAlign",
    "VertAlign",
    # Colors
    "Background",
    "SolidColor",
    "VerticalGradientColor",
    # Protocols
    "ChartDataProtocol",
    "TimeSeriesDataProtocol",
    "SeriesOptionsProtocol",
    "ChartOptionsProtocol",
    "SeriesProtocol",
    "ChartProtocol",
    "MarkerProtocol",
    "TradeProtocol",
    "AnnotationProtocol",
    "TooltipProtocol",
    "VisualizationOptionsProtocol",
    # Type aliases
    "ChartData",
    "SeriesOptions",
    "ChartOptions",
    "TimeValue",
    "NumericValue",
]
