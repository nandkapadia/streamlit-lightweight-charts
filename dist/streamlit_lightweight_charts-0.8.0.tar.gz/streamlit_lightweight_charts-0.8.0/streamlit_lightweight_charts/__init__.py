"""
Streamlit Lightweight Charts - Enhanced OOP Implementation

A comprehensive financial charting library for Streamlit with enhanced trade visualization
and annotation systems, built on TradingView's lightweight-charts.
"""
# pylint: disable=wrong-import-position

import os
import streamlit.components.v1 as components

# Component setup
_COMPONENT_NAME = "streamlit_lightweight_charts"
_RELEASE = True

parent_dir = os.path.dirname(os.path.abspath(__file__))
build_dir = os.path.join(parent_dir, "frontend", "build")

# Ensure the build directory exists
if not os.path.exists(build_dir):
    raise FileNotFoundError(f"Frontend build directory not found: {build_dir}")


if not _RELEASE:
    _component_func = components.declare_component(
        _COMPONENT_NAME,
        url="http://localhost:3001",
    )
else:
    _component_func = components.declare_component(_COMPONENT_NAME, path=build_dir)

# Export the component function for internal use
__all__ = ["_component_func"]

# Import all chart classes
from .charts import (
    Chart,
    MultiPaneChart,
    CandlestickChart,
    LineChart,
    AreaChart,
    BarChart,
    HistogramChart,
    BaselineChart,
    PriceVolumeChart,
    ComparisonChart,
    ChartOptions,
    LayoutOptions,
    GridOptions,
    GridLineOptions,
    CrosshairOptions,
    CrosshairLineOptions,
    PriceScaleOptions,
    TimeScaleOptions,
    PriceScaleMargins,
    WatermarkOptions,
    Series,
    AreaSeries,
    LineSeries,
    BarSeries,
    CandlestickSeries,
    HistogramSeries,
    BaselineSeries,
    AreaSeriesOptions,
    LineSeriesOptions,
    BarSeriesOptions,
    CandlestickSeriesOptions,
    HistogramSeriesOptions,
    BaselineSeriesOptions,
)


# Import all data models
from .data import (
    SingleValueData,
    OhlcData,
    HistogramData,
    BaselineData,
    Marker,
    MarkerShape,
    MarkerPosition,
    Trade,
    TradeType,
    TradeVisualization,
    TradeVisualizationOptions,
    Annotation,
    AnnotationLayer,
    AnnotationManager,
    AnnotationType,
    AnnotationPosition,
    create_text_annotation,
    create_arrow_annotation,
    create_shape_annotation,
)

# Import all utilities
from .utils import (
    df_to_line_data,
    df_to_ohlc_data,
    df_to_histogram_data,
    df_to_baseline_data,
    df_to_data,
    resample_df_for_charts,
    candlestick_chart_from_df,
    line_chart_from_df,
    area_chart_from_df,
    bar_chart_from_df,
    histogram_chart_from_df,
    baseline_chart_from_df,
    trades_to_visual_elements,
    create_trade_shapes_series,
    add_trades_to_series,
)

# Import types and enums
from .type_definitions.enums import (
    ChartType,
    ColorType,
    LineStyle,
    LineType,
    CrosshairMode,
    LastPriceAnimationMode,
    PriceScaleMode,
    HorzAlign,
    VertAlign,
)

from .type_definitions.colors import (
    SolidColor,
    VerticalGradientColor,
    Background,
)

from .type_definitions.protocols import ChartData

# Import rendering function
from .rendering import render_chart

# Original renderLightweightCharts function for backward compatibility
# pylint: disable=invalid-name
def renderLightweightCharts(charts, key=None):
    """
    Original renderLightweightCharts function for backward compatibility.
    
    Args:
        charts: List of chart configurations (dictionaries)
        key: Unique key for the Streamlit component
    
    Returns:
        Component render result
    """
    return render_chart(charts, key=key)

# Import data samples
from .dataSamples import (
    seriesSingleValueData,
    seriesBaselineChart,
    seriesHistogramChart,
    seriesBarChart,
    seriesCandlestickChart,
    seriesMultipleChartArea01,
    seriesMultipleChartArea02,
    priceVolumeSeriesArea,
)

# Version info
__version__ = "0.8.0"
__author__ = "Streamlit Lightweight Charts Contributors"
__description__ = (
    "Enhanced financial charting library for Streamlit with OOP architecture"
)

# Main exports - everything that exists
__all__ = [
    # Core chart classes
    "Chart",
    "MultiPaneChart",
    "CandlestickChart",
    "LineChart",
    "AreaChart",
    "BarChart",
    "HistogramChart",
    "BaselineChart",
    "PriceVolumeChart",
    "ComparisonChart",
    # Chart options
    "ChartOptions",
    "LayoutOptions",
    "GridOptions",
    "GridLineOptions",
    "CrosshairOptions",
    "CrosshairLineOptions",
    "PriceScaleOptions",
    "TimeScaleOptions",
    "PriceScaleMargins",
    "WatermarkOptions",
    # Series classes
    "Series",
    "AreaSeries",
    "LineSeries",
    "BarSeries",
    "CandlestickSeries",
    "HistogramSeries",
    "BaselineSeries",
    "AreaSeriesOptions",
    "LineSeriesOptions",
    "BarSeriesOptions",
    "CandlestickSeriesOptions",
    "HistogramSeriesOptions",
    "BaselineSeriesOptions",
    # Data models
    "SingleValueData",
    "OhlcData",
    "HistogramData",
    "BaselineData",
    "Marker",
    "MarkerShape",
    "MarkerPosition",
    # Trade visualization
    "Trade",
    "TradeType",
    "TradeVisualization",
    "TradeVisualizationOptions",
    # Annotation system
    "Annotation",
    "AnnotationLayer",
    "AnnotationManager",
    "AnnotationType",
    "AnnotationPosition",
    "create_text_annotation",
    "create_arrow_annotation",
    "create_shape_annotation",
    # Utilities
    "df_to_line_data",
    "df_to_ohlc_data",
    "df_to_histogram_data",
    "df_to_baseline_data",
    "df_to_data",
    "resample_df_for_charts",
    "candlestick_chart_from_df",
    "line_chart_from_df",
    "area_chart_from_df",
    "bar_chart_from_df",
    "histogram_chart_from_df",
    "baseline_chart_from_df",
    "trades_to_visual_elements",
    "create_trade_shapes_series",
    "add_trades_to_series",
    # Types and enums
    "ChartType",
    "ColorType",
    "LineStyle",
    "LineType",
    "CrosshairMode",
    "LastPriceAnimationMode",
    "PriceScaleMode",
    "HorzAlign",
    "VertAlign",
    # Colors
    "SolidColor",
    "VerticalGradientColor",
    "Background",
    # Protocols
    "ChartData",
    # Rendering
    "render_chart",
    "renderLightweightCharts",
    # Data samples
    "seriesSingleValueData",
    "seriesBaselineChart",
    "seriesHistogramChart",
    "seriesBarChart",
    "seriesCandlestickChart",
    "seriesMultipleChartArea01",
    "seriesMultipleChartArea02",
    "priceVolumeSeriesArea",
    # Version info
    "__version__",
    "__author__",
    "__description__",
]
