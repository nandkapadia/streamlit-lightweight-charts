"""Chart classes for streamlit-lightweight-charts."""

from typing import List, Optional, Dict, Any, Union
from .options import ChartOptions
from .series import Series
from ..data import Annotation, AnnotationManager


class Chart:
    """Main chart class for creating single-pane charts."""

    def __init__(
        self,
        series: Union[Series, List[Series]],
        options: Optional[ChartOptions] = None,
        annotations: Optional[List[Annotation]] = None,
    ):
        """
        Initialize a chart.

        Args:
            series: Single series or list of series to display
            options: Chart configuration options
            annotations: Optional list of annotations
        """
        self.series = series if isinstance(series, list) else [series]
        self.options = options or ChartOptions()
        self.annotation_manager = AnnotationManager()

        # Add annotations if provided
        if annotations:
            default_layer = self.annotation_manager.create_layer("default")
            for annotation in annotations:
                default_layer.add_annotation(annotation)

    def render(self, key: Optional[str] = None) -> Any:
        """
        Render the chart using Streamlit.

        Args:
            key: Unique key for the Streamlit component

        Returns:
            Rendered chart component
        """
        from ..rendering import render_chart

        return render_chart(self, key=key)

    def add_series(self, series: Series) -> "Chart":
        """
        Add a series to the chart.

        Args:
            series: Series to add

        Returns:
            Self for method chaining
        """
        self.series.append(series)
        return self

    def update_options(self, **kwargs) -> "Chart":
        """
        Update chart options.

        Args:
            **kwargs: Options to update

        Returns:
            Self for method chaining
        """
        for key, value in kwargs.items():
            if hasattr(self.options, key):
                setattr(self.options, key, value)
        return self

    def add_annotation(
        self, annotation: Annotation, layer_name: str = "default"
    ) -> "Chart":
        """
        Add an annotation to the chart.

        Args:
            annotation: Annotation to add
            layer_name: Name of the layer to add to

        Returns:
            Self for method chaining
        """
        layer = self.annotation_manager.get_layer(layer_name)
        if layer is None:
            layer = self.annotation_manager.create_layer(layer_name)
        layer.add_annotation(annotation)
        return self

    def add_annotations(
        self, annotations: List[Annotation], layer_name: str = "default"
    ) -> "Chart":
        """
        Add multiple annotations to the chart.

        Args:
            annotations: List of annotations to add
            layer_name: Name of the layer to add to

        Returns:
            Self for method chaining
        """
        for annotation in annotations:
            self.add_annotation(annotation, layer_name)
        return self

    def create_annotation_layer(self, name: str) -> "Chart":
        """
        Create a new annotation layer.

        Args:
            name: Name of the layer

        Returns:
            Self for method chaining
        """
        self.annotation_manager.create_layer(name)
        return self

    def hide_annotation_layer(self, name: str) -> "Chart":
        """
        Hide an annotation layer.

        Args:
            name: Name of the layer to hide

        Returns:
            Self for method chaining
        """
        layer = self.annotation_manager.get_layer(name)
        if layer:
            layer.hide()
        return self

    def show_annotation_layer(self, name: str) -> "Chart":
        """
        Show an annotation layer.

        Args:
            name: Name of the layer to show

        Returns:
            Self for method chaining
        """
        layer = self.annotation_manager.get_layer(name)
        if layer:
            layer.show()
        return self

    def clear_annotations(self, layer_name: Optional[str] = None) -> "Chart":
        """
        Clear annotations from a layer or all layers.

        Args:
            layer_name: Name of the layer to clear, or None to clear all layers

        Returns:
            Self for method chaining
        """
        if layer_name:
            layer = self.annotation_manager.get_layer(layer_name)
            if layer:
                layer.clear_annotations()
        else:
            self.annotation_manager.clear_all_layers()
        return self

    def to_frontend_config(self) -> Dict[str, Any]:
        """
        Convert chart to frontend-compatible configuration.

        Returns:
            Dictionary with chart configuration for frontend
        """
        # Get all annotation layers
        annotation_layers = []
        for layer_name, layer in self.annotation_manager.layers.items():
            annotation_layers.append(
                {
                    "name": layer_name,
                    "annotations": [ann.to_dict() for ann in layer.annotations],
                    "visible": layer.visible,
                    "opacity": layer.opacity,
                }
            )

        return {
            "chartId": f"chart-{id(self)}",  # Add unique chart ID
            "chart": self.options.to_dict(),
            "series": [s.to_frontend_config() for s in self.series],
            "annotations": [
                ann.to_dict() for ann in self.annotation_manager.get_all_annotations()
            ],
            "annotationLayers": annotation_layers,
        }


class MultiPaneChart:
    """Chart class for creating multi-pane charts."""

    def __init__(self, charts: Optional[List[Chart]] = None):
        """
        Initialize a multi-pane chart.

        Args:
            charts: List of charts to display in separate panes
        """
        self.charts = charts or []

    def add_pane(self, chart: Chart) -> "MultiPaneChart":
        """
        Add a pane to the multi-pane chart.

        Args:
            chart: Chart to add as a new pane

        Returns:
            Self for method chaining
        """
        self.charts.append(chart)
        return self

    def render(self, key: Optional[str] = None) -> Any:
        """
        Render the multi-pane chart using Streamlit.

        Args:
            key: Unique key for the Streamlit component

        Returns:
            Rendered chart component
        """
        from ..rendering import render_multi_pane_chart

        return render_multi_pane_chart(self, key=key)

    def to_frontend_config(self) -> List[Dict[str, Any]]:
        """
        Convert multi-pane chart to frontend-compatible configuration.

        Returns:
            List of chart configurations for frontend
        """
        return [chart.to_frontend_config() for chart in self.charts]
