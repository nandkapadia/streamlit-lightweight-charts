"""
Data Toggling Example

This example demonstrates how to toggle between different datasets in an area chart.
"""

import streamlit as st
from streamlit_lightweight_charts import AreaChart, render_chart
import streamlit_lightweight_charts.dataSamples as data

st.subheader("Data Toggling for an Area Chart")

data_select = st.sidebar.radio("Select data source:", ("Area 01", "Area 02"))

if data_select == "Area 01":
    # Create area chart with first dataset
    chart = AreaChart(data.seriesMultipleChartArea01)
else:
    # Create area chart with second dataset
    chart = AreaChart(data.seriesMultipleChartArea02)

# Render the chart
render_chart(chart, key="area")
