"""
Overlaid Areas Chart Example

This example demonstrates how to create overlaid area charts with markers using the new OOP architecture.
"""

import streamlit as st
from streamlit_lightweight_charts import MultiPaneChart, render_chart
from streamlit_lightweight_charts.charts import AreaSeries, Chart
from streamlit_lightweight_charts.charts.options import (
    ChartOptions, LayoutOptions, GridOptions, GridLineOptions, PriceScaleOptions, PriceScaleMargins, TimeScaleOptions
)
from streamlit_lightweight_charts.data import Marker, MarkerShape, MarkerPosition
from streamlit_lightweight_charts.type_definitions.colors import Background
from streamlit_lightweight_charts.type_definitions.enums import LineStyle, PriceScaleMode
import streamlit_lightweight_charts.dataSamples as data

# Create chart options
chart_options = ChartOptions(
    layout=LayoutOptions(
        background=Background.solid("#100841"),
        text_color="#ffffff"
    ),
    grid=GridOptions(
        vert_lines=GridLineOptions(color="rgba(197, 203, 206, 0.4)", style=LineStyle.SOLID),
        horz_lines=GridLineOptions(color="rgba(197, 203, 206, 0.4)", style=LineStyle.SOLID)
    ),
    right_price_scale=PriceScaleOptions(
        scale_margins=PriceScaleMargins(top=0.1, bottom=0.1),
        mode=PriceScaleMode.NORMAL,
        border_color="rgba(197, 203, 206, 0.4)"
    ),
    time_scale=TimeScaleOptions(
        border_color="rgba(197, 203, 206, 0.4)"
    )
)

# Create markers for first series
markers1 = [
    Marker(
        time="2019-04-08",
        position=MarkerPosition.ABOVE_BAR,
        color="rgba(255, 192, 0, 1)",
        shape=MarkerShape.ARROW_DOWN,
        text="H",
        size=3
    ),
    Marker(
        time="2019-05-13",
        position=MarkerPosition.BELOW_BAR,
        color="rgba(255, 192, 0, 1)",
        shape=MarkerShape.ARROW_UP,
        text="L",
        size=3
    )
]

# Create markers for second series
markers2 = [
    Marker(
        time="2019-05-03",
        position=MarkerPosition.ABOVE_BAR,
        color="rgba(67, 83, 254, 1)",
        shape=MarkerShape.ARROW_DOWN,
        text="PEAK",
        size=3
    )
]

# Create area series
series1 = AreaSeries(
    data=data.seriesMultipleChartArea01,
    options={
        "topColor": "rgba(255, 192, 0, 0.7)",
        "bottomColor": "rgba(255, 192, 0, 0.3)",
        "lineColor": "rgba(255, 192, 0, 1)",
        "lineWidth": 2
    },
    markers=markers1
)

series2 = AreaSeries(
    data=data.seriesMultipleChartArea02,
    options={
        "topColor": "rgba(67, 83, 254, 0.7)",
        "bottomColor": "rgba(67, 83, 254, 0.3)",
        "lineColor": "rgba(67, 83, 254, 1)",
        "lineWidth": 2
    },
    markers=markers2
)

# Create charts with the series
chart1 = Chart(series1, options=chart_options)
chart2 = Chart(series2, options=chart_options)

# Create multi-pane chart with both charts
chart = MultiPaneChart()
chart.add_pane(chart1)
chart.add_pane(chart2)

st.subheader("Overlaid Series with Markers")

# Render the chart
render_chart(chart, key="overlaid")
