"""Chart rendering functionality for streamlit-lightweight-charts."""

import os
from typing import List, Dict, Any, Optional, Union
import streamlit.components.v1 as components
from .charts import Chart, MultiPaneChart


# Get the component function from the main module
def _get_component_func():
    """Get the component function from the main module."""
    try:
        # Import the main module and get the component function
        from . import _component_func # pylint: disable=import-outside-toplevel

        return _component_func
    except ImportError:
        # Fallback: declare the component
        parent_dir = os.path.dirname(os.path.abspath(__file__))
        build_dir = os.path.join(parent_dir, "frontend", "build")

        return components.declare_component(
            "streamlit_lightweight_charts", path=build_dir
        )


def render_chart(
    charts: Union[
        List[Union[Chart, Dict[str, Any]]], Chart, Dict[str, Any], MultiPaneChart
    ],
    key: Optional[str] = None,
    height: int = 400,
    width: int = 800,
    sync_config: Optional[Dict[str, Any]] = None,
) -> Any:
    """
    Render lightweight charts using Streamlit component.

    Args:
        charts: Chart object(s) or chart configuration(s)
        key: Unique key for the Streamlit component
        height: Chart height in pixels
        width: Chart width in pixels
        sync_config: Configuration for chart synchronization

    Returns:
        Component render result
    """
    # Convert to list of chart configs
    chart_configs = []

    if isinstance(charts, MultiPaneChart):
        # MultiPaneChart case
        chart_configs = [chart.to_frontend_config() for chart in charts.charts]
    elif isinstance(charts, (Chart, dict)):
        # Single chart case
        if isinstance(charts, Chart):
            chart_configs = [charts.to_frontend_config()]
        else:
            chart_configs = [charts]
    else:
        # List case
        for chart in charts:
            if isinstance(chart, Chart):
                chart_configs.append(chart.to_frontend_config())
            else:
                chart_configs.append(chart)

    # Create component config
    component_config = {
        "charts": chart_configs,
        "syncConfig": sync_config
        or {"enabled": False, "crosshair": True, "timeRange": True},
        "height": height,
        "width": width,
    }

    return _get_component_func()(config=component_config, key=key)


def render_multi_pane_chart(
    chart: MultiPaneChart,
    key: Optional[str] = None,
    height: int = 400,
    width: int = 800,
) -> Any:
    """
    Render a multi-pane chart specifically.

    Args:
        chart: MultiPaneChart object
        key: Unique key for the Streamlit component
        height: Chart height in pixels
        width: Chart width in pixels

    Returns:
        Component render result
    """
    return render_chart(
        charts=chart,
        key=key,
        height=height,
        width=width,
        sync_config={"enabled": True, "crosshair": True, "timeRange": True},
    )
