from typing import Union
from datetime import datetime
import pandas as pd


def to_utc_timestamp(
    time_value: Union[str, int, float, datetime, pd.Timestamp],
) -> Union[str, int]:
    """
    Convert various time formats to UTC timestamp.
    Args:
        time_value: Time in various formats
    Returns:
        UTC timestamp (int) or date string (str) for compatibility
    """
    if isinstance(time_value, str):
        # Try to parse as date string
        try:
            pd.to_datetime(time_value)
            return time_value
        except:
            return time_value
    elif isinstance(time_value, (int, float)):
        return int(time_value)
    elif isinstance(time_value, datetime):
        return int(time_value.timestamp())
    elif isinstance(time_value, pd.Timestamp):
        return int(time_value.timestamp())
    else:
        raise ValueError(f"Unsupported time type: {type(time_value)}")


def from_utc_timestamp(time_value: Union[str, int]) -> pd.Timestamp:
    """
    Convert UTC timestamp or date string to pandas Timestamp.
    Args:
        time_value: UTC timestamp or date string
    Returns:
        Pandas Timestamp
    """
    if isinstance(time_value, str):
        return pd.to_datetime(time_value)
    elif isinstance(time_value, (int, float)):
        return pd.to_datetime(time_value, unit="s")
    else:
        raise ValueError(f"Unsupported time type: {type(time_value)}")
